#pragma once

#include "RS485.h"

extern hw::RS485 Serial_RS485;