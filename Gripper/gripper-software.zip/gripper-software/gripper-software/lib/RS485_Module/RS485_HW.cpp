
#include "RS485_HW.h"
#include <Arduino.h>

hw::RS485 Serial_RS485(Serial3, 3,4);